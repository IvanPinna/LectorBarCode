package com.example.lectorbarcode;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button scanBtn;
    private TextView contentTxt;
    private Vector<String> codigos = new Vector<String>();
    private int contador = 0;
    private DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()); //ew SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

    @Override
    protected void onCreate(Bundle savedInstanceState) { //Escanea un codigo de barras
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scanBtn = (Button)findViewById(R.id.scan_button);
        contentTxt = (TextView)findViewById(R.id.scan_content);

        scanBtn.setOnClickListener(this);
    }

    public void onClick(View v){
        //Responds to clicks
        if(v.getId() == R.id.scan_button){
            IntentIntegrator scanIntegrator = new IntentIntegrator(this);
            scanIntegrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
            scanIntegrator.setBeepEnabled(false);
            scanIntegrator.initiateScan();
        }
    }

    @Override
    protected  void onActivityResult(int requestCode, int resultCode, Intent data) //Devuelve el codigo
    {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        if(result == null){
            Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
        }else{
            String scanContent = result.getContents();
            Date date = new Date();
            String f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
            codigos.add(f + "   " + scanContent);
            contentTxt.setText(codigos.elementAt(contador));
            ++contador;

        }
    }
}
